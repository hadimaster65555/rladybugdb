#include "binder/expression/aggregate_function_expression.h"

#include "binder/expression/expression_util.h"
#include "common/string_format.h"

using namespace lbug::common;

namespace lbug {
namespace binder {

std::string AggregateFunctionExpression::toStringInternal() const {
    return lbug::common::stringFormat("{}({}{})", function.name, function.isDistinct ? "DISTINCT " : "",
        ExpressionUtil::toString(children));
}

std::string AggregateFunctionExpression::getUniqueName(const std::string& functionName,
    const expression_vector& children, bool isDistinct) {
    return lbug::common::stringFormat("{}({}{})", functionName, isDistinct ? "DISTINCT " : "",
        ExpressionUtil::getUniqueName(children));
}

} // namespace binder
} // namespace lbug
