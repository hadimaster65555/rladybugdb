#include "common/enums/storage_format.h"

#include "common/exception/binder.h"
#include "common/string_format.h"

namespace lbug {
namespace common {

StorageFormat StorageFormatUtils::fromString(const std::string& str) {
    if (str == "icebug-disk") {
        return StorageFormat::ICEBUG_DISK;
    }
    throw BinderException(
        lbug::common::stringFormat("Unsupported storage format '{}'. Valid options are: icebug-disk.", str));
}

} // namespace common
} // namespace lbug
