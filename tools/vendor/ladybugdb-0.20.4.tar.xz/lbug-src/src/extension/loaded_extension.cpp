#include "extension/loaded_extension.h"

#include "common/assert.h"
#include "common/string_format.h"

namespace lbug {
namespace extension {

std::string LoadedExtension::toCypher() {
    switch (source) {
    case ExtensionSource::OFFICIAL:
        return lbug::common::stringFormat("INSTALL {};\nLOAD EXTENSION {};\n", extensionName, extensionName);
    case ExtensionSource::USER:
        return lbug::common::stringFormat("LOAD EXTENSION '{}';\n", fullPath);
    case ExtensionSource::STATIC_LINKED:
        return "";
    default:
        UNREACHABLE_CODE;
    }
}

} // namespace extension
} // namespace lbug
