## ----setup, include = FALSE---------------------------------------------------
library(rladybugdb)
knitr::opts_chunk$set(
  collapse  = TRUE,
  comment   = "#>",
  eval      = ladybugdb_is_installed()
)

## ----version------------------------------------------------------------------
library(rladybugdb)
ladybugdb_version()      # e.g. "0.15.2"
ladybugdb_is_installed() # TRUE

## ----open-db------------------------------------------------------------------
library(rladybugdb)

db   <- lb_database(":memory:")
conn <- lb_connection(db)
db
conn

## ----schema-------------------------------------------------------------------
# Node tables
lb_execute(conn, "CREATE NODE TABLE Person (
  name   STRING,
  age    INT64,
  PRIMARY KEY (name)
)")

lb_execute(conn, "CREATE NODE TABLE City (
  name    STRING,
  country STRING,
  PRIMARY KEY (name)
)")

# Relationship table (directed: Person → City)
lb_execute(conn, "CREATE REL TABLE LivesIn (FROM Person TO City, since INT64)")

## ----insert-------------------------------------------------------------------
lb_execute(conn, "CREATE (:Person {name: 'Alice', age: 30})")
lb_execute(conn, "CREATE (:Person {name: 'Bob',   age: 25})")
lb_execute(conn, "CREATE (:City   {name: 'London', country: 'UK'})")
lb_execute(conn, "CREATE (:City   {name: 'Paris',  country: 'France'})")

lb_execute(conn, "
  MATCH (p:Person {name: 'Alice'}), (c:City {name: 'London'})
  CREATE (p)-[:LivesIn {since: 2018}]->(c)
")
lb_execute(conn, "
  MATCH (p:Person {name: 'Bob'}), (c:City {name: 'Paris'})
  CREATE (p)-[:LivesIn {since: 2021}]->(c)
")

## ----bulk-load----------------------------------------------------------------
more_people <- data.frame(
  name = c("Carol", "Dave"),
  age  = c(35L,     28L)
)
lb_copy_from_df(conn, more_people, "Person")

lb_query(conn, "MATCH (p:Person) RETURN p.name AS name, p.age AS age ORDER BY p.name")

## ----query-df-----------------------------------------------------------------
df <- lb_query(conn,
  "MATCH (p:Person)-[:LivesIn]->(c:City)
   RETURN p.name AS person, c.name AS city, c.country AS country
   ORDER BY p.name")
df

## ----query-execute------------------------------------------------------------
result <- lb_execute(conn,
  "MATCH (p:Person) RETURN p.name AS name, p.age AS age ORDER BY p.age")
result          # prints column schema
as.data.frame(result)

## ----params-------------------------------------------------------------------
lb_execute(conn,
  "MATCH (p:Person {name: $name}) RETURN p.age AS age",
  parameters = list(name = "Alice"))

## ----query-tibble, eval = ladybugdb_is_installed() && requireNamespace("tibble", quietly = TRUE)----
result <- lb_execute(conn,
  "MATCH (p:Person) RETURN p.name AS name, p.age AS age ORDER BY p.age")
tibble::as_tibble(result)

## ----query-arrow, eval = ladybugdb_is_installed() && requireNamespace("arrow", quietly = TRUE)----
result <- lb_execute(conn,
  "MATCH (p:Person) RETURN p.name AS name, p.age AS age")
as_arrow_table(result)

## ----igraph, eval = ladybugdb_is_installed() && requireNamespace("igraph", quietly = TRUE)----
result <- lb_execute(conn,
  "MATCH (p:Person)-[r:LivesIn]->(c:City) RETURN p, r, c")
g <- as_igraph(result)
print(g)

## ----tidygraph, eval = ladybugdb_is_installed() && requireNamespace("tidygraph", quietly = TRUE)----
result2 <- lb_execute(conn,
  "MATCH (p:Person)-[r:LivesIn]->(c:City) RETURN p, r, c")
tg <- as_tbl_graph(result2)
tg

## ----cleanup------------------------------------------------------------------
lb_close(conn)
lb_close(db)

