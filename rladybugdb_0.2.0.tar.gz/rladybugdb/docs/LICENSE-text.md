# License

    YEAR: 2026
    COPYRIGHT HOLDER: rladybugdb authors
